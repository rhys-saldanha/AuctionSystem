compile all java files

to start server

	java Server
	
to start client

	java Client

only one Server can be ran at a given time
more than one Client can be ran
