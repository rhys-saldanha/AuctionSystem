public class ExitMessage implements Message
{
}
