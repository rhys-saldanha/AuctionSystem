public class StringMessage implements Message
{
	StringMessage(String s)
	{
		this.s = s;
	}

	public final String s;
}
